class PostSerializer:
    pass


class PostDetailSerializer:
    pass


class CommentSerializer:
    pass
