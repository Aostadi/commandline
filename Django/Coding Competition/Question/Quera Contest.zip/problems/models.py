from django.db import models


class Problem(models.Model):
    pass


class Submission(models.Model):
    pass
