from Users.models import Birthday
from django.contrib import admin

#from django_jalali.admin.filters import JDateFieldListFilter
#import django_jalali.admin as jadmin


admin.site.register(Birthday)

