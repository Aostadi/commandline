from django.db import models


class CustomUser(models.Model):
    pass
