from django import forms


class CustomUserForm(forms.ModelForm):
    pass
