from django.core.management.base import BaseCommand, CommandError
from career.models import Company


class Command(BaseCommand):
    pass
