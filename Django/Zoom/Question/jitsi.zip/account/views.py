def home(request):
    pass


def signup(request):
    pass


def login_account(request):
    pass


def logout_account(request):
    pass


@login_required
def joinoradd_team(request):
    pass


def exit_team(request):
    pass